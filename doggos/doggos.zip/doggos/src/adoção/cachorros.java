package adoção;

public class cachorros extends animais {


    public String getNome() {
        return nome();
    }
    public String getCor() {
        return cor();
    }
    public String getRaça(){
        return raça();
    }
    public String getIdade() {
        return idade();
    }
    public String getLocalização(){
        return localização();
    }

}

